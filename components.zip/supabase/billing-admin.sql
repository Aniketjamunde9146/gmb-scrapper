-- =====================================================================
-- GMB Scraper: credits, UPI payments (UTR + WhatsApp proof) and admin role
-- Run ONCE in Supabase -> SQL Editor (after schema.sql). Safe to re-run.
-- =====================================================================

-- 1) One profile row per user. `role` is where the admin panel reads admin access from.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  role text not null default 'user' check (role in ('user', 'admin')),
  free_used int not null default 0 check (free_used >= 0),
  credits int not null default 0 check (credits >= 0),
  created_at timestamptz not null default now()
);

-- Every new signup (email or Google) automatically gets a profile.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id) values (new.id) on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- Existing users get a profile too.
insert into public.profiles (id) select id from auth.users on conflict (id) do nothing;

-- 2) Admin check used by every policy and function below. It reads the role from profiles.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select coalesce((select role = 'admin' from public.profiles where id = auth.uid()), false);
$$;

-- 3) Credit packs (the single source of truth for price and size).
--    Keep lib/billing.ts (the labels shown in the UI) in step with these rows.
create table if not exists public.credit_packs (
  id text primary key,
  name text not null,
  credits int not null check (credits > 0),
  price_inr int not null check (price_inr > 0),
  active boolean not null default true
);
insert into public.credit_packs (id, name, credits, price_inr) values
  ('starter', 'Starter', 20, 199),
  ('growth',  'Growth',  60, 499),
  ('pro',     'Pro',    150, 999)
on conflict (id) do update set name = excluded.name, credits = excluded.credits, price_inr = excluded.price_inr;

-- 4) Payments: the user submits a UTR, the admin approves, credits are added.
create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  email text not null default '',
  pack text not null references public.credit_packs(id),
  credits int not null check (credits > 0),
  amount_inr int not null check (amount_inr > 0),
  utr text not null check (utr ~ '^[0-9]{12}$'),
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  admin_note text,
  created_at timestamptz not null default now(),
  reviewed_at timestamptz,
  reviewed_by uuid references auth.users(id)
);
create index if not exists payments_user_created on public.payments (user_id, created_at desc);
create index if not exists payments_status_created on public.payments (status, created_at desc);
-- The same UTR can never be used twice (a rejected one can be re-submitted).
create unique index if not exists payments_utr_active on public.payments (utr) where status <> 'rejected';

-- 5) Search tickets: lets the server refund a search that failed, without users being able to abuse it.
create table if not exists public.search_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  source text not null check (source in ('free', 'credit')),
  refunded boolean not null default false,
  created_at timestamptz not null default now()
);

-- 6) Row Level Security. Users can read their own rows and can NEVER write profiles/payments directly.
alter table public.profiles enable row level security;
alter table public.credit_packs enable row level security;
alter table public.payments enable row level security;
alter table public.search_tickets enable row level security;   -- no policies: invisible to clients

drop policy if exists "read own profile" on public.profiles;
create policy "read own profile" on public.profiles for select using (auth.uid() = id or public.is_admin());

drop policy if exists "read packs" on public.credit_packs;
create policy "read packs" on public.credit_packs for select using (true);

drop policy if exists "read own payments" on public.payments;
create policy "read own payments" on public.payments for select using (auth.uid() = user_id or public.is_admin());

revoke insert, update, delete on public.profiles from anon, authenticated;
revoke insert, update, delete on public.payments from anon, authenticated;
revoke insert, update, delete on public.credit_packs from anon, authenticated;
revoke all on public.search_tickets from anon, authenticated;

-- 7) Functions the app calls (all check who is calling).

-- Spend one search: 3 free lifetime searches first, then 1 credit. Atomic, so double clicks cannot overspend.
create or replace function public.consume_search()
returns jsonb language plpgsql security definer set search_path = public as $$
declare p public.profiles; src text; t uuid;
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  update public.profiles set free_used = free_used + 1 where id = auth.uid() and free_used < 3 returning * into p;
  if found then src := 'free';
  else
    update public.profiles set credits = credits - 1 where id = auth.uid() and credits > 0 returning * into p;
    if found then src := 'credit';
    else return jsonb_build_object('ok', false); end if;
  end if;
  insert into public.search_tickets (user_id, source) values (auth.uid(), src) returning id into t;
  return jsonb_build_object('ok', true, 'ticket', t, 'free_left', greatest(3 - p.free_used, 0), 'credits', p.credits);
end $$;

-- Give the search back if it failed on our side. Needs the secret ticket id, and works once per ticket.
create or replace function public.refund_search(p_ticket uuid)
returns void language plpgsql security definer set search_path = public as $$
declare t public.search_tickets;
begin
  update public.search_tickets set refunded = true
    where id = p_ticket and user_id = auth.uid() and refunded = false and created_at > now() - interval '5 minutes'
    returning * into t;
  if not found then return; end if;
  if t.source = 'free' then update public.profiles set free_used = greatest(free_used - 1, 0) where id = t.user_id;
  else update public.profiles set credits = credits + 1 where id = t.user_id; end if;
end $$;

-- The user reports a payment. Price and credits come from credit_packs, never from the browser.
create or replace function public.submit_payment(p_pack text, p_utr text)
returns public.payments language plpgsql security definer set search_path = public as $$
declare k public.credit_packs; r public.payments; v_utr text := regexp_replace(coalesce(p_utr, ''), '\s', '', 'g');
begin
  if auth.uid() is null then raise exception 'not_authenticated'; end if;
  if v_utr !~ '^[0-9]{12}$' then raise exception 'bad_utr'; end if;
  select * into k from public.credit_packs where id = p_pack and active;
  if not found then raise exception 'bad_pack'; end if;
  if (select count(*) from public.payments where user_id = auth.uid() and status = 'pending') >= 3 then raise exception 'too_many_pending'; end if;
  if exists (select 1 from public.payments pm where pm.utr = v_utr and pm.status <> 'rejected') then raise exception 'utr_used'; end if;
  insert into public.payments (user_id, email, pack, credits, amount_inr, utr)
    values (auth.uid(), coalesce(auth.jwt() ->> 'email', ''), k.id, k.credits, k.price_inr, v_utr)
    returning * into r;
  return r;
end $$;

-- Admin only: approve a payment and add the credits in one step.
create or replace function public.approve_payment(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
declare r public.payments;
begin
  if not public.is_admin() then raise exception 'not_admin'; end if;
  update public.payments set status = 'approved', reviewed_at = now(), reviewed_by = auth.uid()
    where id = p_id and status = 'pending' returning * into r;
  if not found then raise exception 'not_pending'; end if;
  update public.profiles set credits = credits + r.credits where id = r.user_id;
end $$;

-- Admin only: reject a payment with an optional note the user can read.
create or replace function public.reject_payment(p_id uuid, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'not_admin'; end if;
  update public.payments set status = 'rejected', admin_note = left(p_note, 300), reviewed_at = now(), reviewed_by = auth.uid()
    where id = p_id and status = 'pending';
  if not found then raise exception 'not_pending'; end if;
end $$;

-- Only signed-in users may call these.
revoke execute on function public.is_admin(), public.consume_search(), public.refund_search(uuid),
  public.submit_payment(text, text), public.approve_payment(uuid), public.reject_payment(uuid, text) from public, anon;
grant execute on function public.is_admin(), public.consume_search(), public.refund_search(uuid),
  public.submit_payment(text, text), public.approve_payment(uuid), public.reject_payment(uuid, text) to authenticated;

-- =====================================================================
-- 8) MAKE YOURSELF ADMIN. Sign up on the site first, then run this with YOUR email:
-- =====================================================================
-- update public.profiles set role = 'admin'
--   where id = (select id from auth.users where email = 'you@example.com');
--
-- Check it:   select p.role, u.email from public.profiles p join auth.users u on u.id = p.id where p.role = 'admin';
-- Remove it:  update public.profiles set role = 'user' where id = (select id from auth.users where email = 'you@example.com');
