-- Run this once in Supabase → SQL Editor.
create table if not exists public.searches (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  q text not null,
  city text not null,
  total int not null default 0,
  with_phone int not null default 0,
  no_website int not null default 0,
  created_at timestamptz not null default now()
);
create index if not exists searches_user_created on public.searches (user_id, created_at desc);

create table if not exists public.saved_leads (
  user_id uuid not null references auth.users(id) on delete cascade,
  lead_id text not null,
  lead jsonb not null,
  status text not null default 'new' check (status in ('new','contacted','interested','won','lost')),
  note text not null default '',
  created_at timestamptz not null default now(),
  primary key (user_id, lead_id)
);
-- If you created saved_leads earlier without notes:
alter table public.saved_leads add column if not exists note text not null default '';

-- Follow-up reminders (date the lead should be contacted again):
alter table public.saved_leads add column if not exists follow_up date;

alter table public.searches enable row level security;
alter table public.saved_leads enable row level security;

drop policy if exists "own searches" on public.searches;
create policy "own searches" on public.searches for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
drop policy if exists "own saved" on public.saved_leads;
create policy "own saved" on public.saved_leads for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
