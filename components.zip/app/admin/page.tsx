import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, ShieldCheck } from "lucide-react";
import { requireAdmin } from "../../lib/auth";
import { listPayments } from "../../lib/billing-db";
import { AdminPayments } from "../../components/admin/admin-payments";
import { Logo } from "../../components/logo";
import { ThemeToggle } from "../../components/theme-toggle";

export const metadata: Metadata = { title: "Admin · Payments", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

/** Only users whose profiles.role is 'admin' in Supabase can open this. Everyone else gets the normal 404 page. */
export default async function AdminPage() {
  await requireAdmin("/admin");
  const [pending, recent] = await Promise.all([listPayments("pending"), listPayments("all", 100)]);
  const done = recent.filter((r) => r.status !== "pending");
  return (
    <div className="min-h-dvh bg-background">
      <header className="sticky top-0 z-20 flex h-16 items-center gap-3 border-b bg-background/80 px-4 backdrop-blur-xl sm:px-6">
        <Logo />
        <span className="inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-medium text-muted-foreground"><ShieldCheck className="size-3.5" aria-hidden /> Admin</span>
        <div className="ml-auto flex items-center gap-2">
          <Link href="/dashboard" className="inline-flex h-10 items-center gap-1.5 rounded-lg border px-3 text-sm text-muted-foreground transition-colors hover:bg-accent"><ArrowLeft className="size-4" aria-hidden /> Dashboard</Link>
          <ThemeToggle />
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl p-4 sm:p-6 lg:p-8">
        <h1 className="text-2xl font-semibold tracking-tight">Payments</h1>
        <p className="mt-1 text-sm text-muted-foreground">Match each UTR with your bank or UPI app, then approve. Approving adds the credits at once.</p>
        <AdminPayments pending={pending} done={done} />
      </main>
    </div>
  );
}
