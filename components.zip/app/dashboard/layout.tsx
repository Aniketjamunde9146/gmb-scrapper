import type { Metadata } from "next";
import { getSession } from "../../lib/auth";
import { getProfile } from "../../lib/billing-db";
import { AppShell } from "../../components/dashboard/app-shell";

export const metadata: Metadata = {
  title: { default: "Dashboard", template: "%s · GMB Scraper" },
  robots: { index: false, follow: false },
};

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  const session = await getSession();
  // Each page calls requireSession() with its own return path; without a session they redirect to /login.
  if (!session) return <>{children}</>;
  const profile = await getProfile(session.uid);
  return (
    <AppShell user={{ name: session.name, email: session.email }} balance={{ freeLeft: profile.freeLeft, credits: profile.credits }} isAdmin={profile.role === "admin"}>
      {children}
    </AppShell>
  );
}
